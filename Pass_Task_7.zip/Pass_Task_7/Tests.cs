using NUnit.Framework;
using System;
using Pass_Task_7;

/**
    <summary>

        This Class contains three tests on the talent class
        (i) BeginnerCast
            This test is meant to test the cast message from the beginner
            class.
        (ii) IntermediateElementalSkill
            This test performs an assertion test on the cast message from
            the talent instane with both Intermediate Level and Elemental
            skill kind.
        (iii) AdvancedAlternateSkill
            This test performs an assertion test on the message returned
            if the talent instance has a level, Advanced and is of kind,
            Alternate Skill.
            
    </summary>

*/

[TestFixture]
public class TalentTests
{
    [Test]
    public void BeginnerCast()
    {
        Talent playerOne = new Talent("The Slayer");
        Assert.AreEqual("\tZapp.. First Stage Triggered", playerOne.Cast());
    }

    [Test]
    public void IntermediateElementalSkill()
    {
        Talent playerTwo = new Talent("The BodyGuard", 2, 2);
        Assert.AreEqual("\tFeel the Force", playerTwo.Cast());

    }

    [Test]
    public void AdvancedAlternateSkill()
    {
        Talent playerThree = new Talent("Princess Danger", 4, 4);
        Assert.AreEqual("\tBe Prepared to Feel the Swirl", playerThree.Cast());
    }

}